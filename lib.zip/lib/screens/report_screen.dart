import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:open_file/open_file.dart';
import '../services/firebase_service.dart';
import '../providers/auth_provider.dart';
import '../services/excel_service.dart'; // Tu nuevo servicio

class ReportScreen extends StatefulWidget {
  final String? casoId;
  const ReportScreen({super.key, this.casoId});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  bool _isGenerating = false;
  Map<String, dynamic>? _casoData;
  String? _grupoNombre;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    _grupoNombre = auth.grupoNombre;
    
    String? id = widget.casoId;
    if (id == null) {
      final args = ModalRoute.of(context)?.settings.arguments as Map?;
      id = args?['casoId'];
    }

    if (id != null) {
      final doc = await FirebaseService.getCasoById(id);
      if (doc.exists) {
        _casoData = doc.data() as Map<String, dynamic>;
      }
    }
    setState(() => _isLoading = false);
  }

  Future<void> _handleGenerarExcel() async {
    if (_casoData == null) return;
    
    setState(() => _isGenerating = true);
    try {
      final path = await ExcelService.generarReporteInspeccion(_casoData!, _grupoNombre ?? "");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ Reporte generado con éxito'), backgroundColor: Colors.green),
        );
        await OpenFile.open(path);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Finalizar Reporte"),
        backgroundColor: const Color(0xFF4F81BD),
        elevation: 0,
      ),
      body: _isLoading 
        ? const Center(child: CircularProgressIndicator())
        : Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF4F81BD), Color(0xFF2E5A88)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  _buildStatusCard(),
                  const Spacer(),
                  _buildDownloadButton(),
                ],
              ),
            ),
          ),
    );
  }

  Widget _buildStatusCard() {
    final isCerrado = _casoData?['cerrado'] == true;
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 8,
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          children: [
            Icon(
              isCerrado ? Icons.check_circle : Icons.pending_actions,
              size: 80,
              color: isCerrado ? Colors.green : Colors.orange,
            ),
            const SizedBox(height: 20),
            Text(
              _casoData?['nombre'] ?? "Caso de Inspección",
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const Divider(height: 30),
            _buildDetailRow("Empresa", _casoData?['empresaNombre'] ?? _grupoNombre ?? "N/A"),
            _buildDetailRow("Estado", isCerrado ? "Completado" : "Pendiente de Cierre"),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.w500)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildDownloadButton() {
    return SizedBox(
      width: double.infinity,
      height: 60,
      child: ElevatedButton.icon(
        onPressed: _isGenerating ? null : _handleGenerarExcel,
        icon: _isGenerating 
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
            : const Icon(Icons.description),
        label: Text(_isGenerating ? "DESCARGANDO IMÁGENES..." : "GENERAR EXCEL CON FOTOS"),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green.shade700,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        ),
      ),
    );
  }
}