// lib/screens/case_list_screen.dart
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../models/case_model.dart';
import '../models/empresa_model.dart';
import '../services/firebase_service.dart';
import '../providers/auth_provider.dart';
import '../providers/interface_config_provider.dart';
import '../widgets/case_form_dialog_firebase.dart';
import '../widgets/case_card.dart';
import '../widgets/empty_cases_state.dart';
import '../widgets/closed_cases_header.dart';
import '../widgets/closed_cases_button.dart';
import '../widgets/configurable_feature.dart';

class CaseListScreen extends StatefulWidget {
  const CaseListScreen({super.key});

  @override
  State<CaseListScreen> createState() => _CaseListScreenState();
}

class _CaseListScreenState extends State<CaseListScreen> {
  // QUITAR 'late' y inicializar con valores por defecto
  Empresa _empresa = Empresa(
    id: "empresa_default",
    nombre: "Empresa X",
    nit: "",
    icon: Icons.business,
  );
  String _empresaId = "empresa_default";
  String? _centroId;
  String? _centroNombre;
  IconData? _empresaIcon;
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    // Inicializar inmediatamente con valores por defecto
    _initializeWithDefaults();
    
    // Usar postFrameCallback para inicializar después del primer build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeData();
    });
  }

  void _initializeWithDefaults() {
    // Establecer valores por defecto inmediatamente
    _empresa = Empresa(
      id: "empresa_default",
      nombre: "Empresa X",
      nit: "",
      icon: Icons.business,
    );
    _empresaId = "empresa_default";
    _empresaIcon = Icons.business;
  }

  void _initializeData() {
    if (_isInitialized) return;
    
    _initializeEmpresaFromArguments();
    _loadInterfaceConfig();
    _isInitialized = true;
  }

  void _initializeEmpresaFromArguments() {
    final args = ModalRoute.of(context)!.settings.arguments as Map?;
    
    if (args != null) {
      setState(() {
        _empresaId = args["empresaId"] ?? "empresa_default";
        _empresa = Empresa(
          id: _empresaId,
          nombre: args["empresaNombre"] ?? "Empresa X",
          nit: args["nit"] ?? "",
          icon: args["icon"] ?? Icons.business,
        );
        _centroId = args["centroId"];
        _centroNombre = args["centroNombre"];
        _empresaIcon = args["icon"];
      });
    }
    // Si no hay argumentos, ya tenemos los valores por defecto
  }

  // Método simplificado: solo cargar configuración sin setState
  void _loadInterfaceConfig() {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final configProvider = Provider.of<InterfaceConfigProvider>(context, listen: false);
    
    if (authProvider.grupoId != null) {
      configProvider.loadConfig(authProvider.grupoId!);
    }
  }

  // Método para obtener el nivel de peligro actualizado
  String _getNivelPeligroActualizado(Map<String, dynamic> data) {
    final estadoAbierto = data['estadoAbierto'] as Map<String, dynamic>?;
    if (estadoAbierto != null && estadoAbierto['nivelPeligro'] != null) {
      return estadoAbierto['nivelPeligro'] as String;
    }
    return data['nivelPeligro'] ?? '';
  }

  // Método para verificar permisos de creación de casos
  bool _puedeCrearCasos(AuthProvider authProvider) {
    // Admin puede crear casos en su grupo, super_admin en todos, inspectores según configuración
    return authProvider.isAdmin || 
           authProvider.isSuperAdmin || 
           (authProvider.isAnyInspector && 
            authProvider.puedeAccederAEmpresa(_empresaId));
  }

  void _openAddCaseModal() {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    
    // Verificar permisos actualizados
    if (!_puedeCrearCasos(authProvider)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No tienes permisos para crear casos'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => CaseFormDialogFirebase(
        empresa: _empresa,
        empresaId: _empresaId,
        centroId: _centroId,
        centroNombre: _centroNombre,
        grupoId: authProvider.grupoId,
        grupoNombre: authProvider.grupoNombre,
      ),
    );
  }

  void _navegarACasosCerrados(List<Case> casosCerrados) {
    Navigator.pushNamed(
      context,
      '/closedCases',
      arguments: {
        "empresa": _empresa,
        "empresaId": _empresaId,
        "centroId": _centroId,
        "centroNombre": _centroNombre,
        "casosCerrados": casosCerrados,
      },
    );
  }

  void _navegarADetalleCaso(String casoId, Case caso) {
    Navigator.pushNamed(
      context,
      '/caseDetail',
      arguments: {
        "casoId": casoId,
        "caso": caso,
      },
    );
  }

  String _getAppBarTitle() {
    if (_centroNombre != null) {
      return 'Casos - $_centroNombre';
    }
    return 'Casos - ${_empresa.nombre}';
  }

  String _getSubtitle() {
    if (_centroNombre != null) {
      return 'Centro: $_centroNombre';
    }
    return 'Empresa: ${_empresa.nombre}';
  }

  // Método para obtener el color del nivel de riesgo según la configuración
  Color? _getNivelRiesgoColor(Case caso, InterfaceConfigProvider configProvider) {
    if (!configProvider.isFeatureEnabled('mostrarNivelRiesgo')) return null;
    
    switch (caso.nivelPeligro) {
      case 'Bajo':
        return Colors.green;
      case 'Medio':
        return Colors.orange;
      case 'Alto':
        return Colors.red[400];
      default:
        return Colors.grey;
    }
  }

  // Método para determinar si mostrar el nivel de riesgo
  bool _debeMostrarNivelRiesgo(Case caso, InterfaceConfigProvider configProvider) {
    return configProvider.isFeatureEnabled('mostrarNivelRiesgo') && 
           caso.nivelPeligro.isNotEmpty && 
           caso.nivelPeligro != 'No aplica';
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final configProvider = Provider.of<InterfaceConfigProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_getAppBarTitle()),
            Text(
              _getSubtitle(),
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
        actions: [
          // Información del grupo
          if (authProvider.grupoNombre != null)
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Center(
                child: Text(
                  authProvider.grupoNombre!,
                  style: const TextStyle(fontSize: 12, color: Colors.white70),
                ),
              ),
            ),
          // Botón de casos cerrados - configurable
          ConfigurableFeature(
            feature: 'mostrarCasosCerrados',
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseService.getCasosPorEmpresaStream(_empresaId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const SizedBox.shrink();
                
                final casosCerrados = snapshot.data!.docs
                    .where((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      return data['cerrado'] == true;
                    })
                    .length;

                if (casosCerrados == 0) return const SizedBox.shrink();

                return ClosedCasesButton(
                  casosCerradosCount: casosCerrados,
                  onPressed: () {
                    final casosCerradosList = snapshot.data!.docs
                        .where((doc) {
                          final data = doc.data() as Map<String, dynamic>;
                          return data['cerrado'] == true;
                        })
                        .map((doc) {
                          final data = doc.data() as Map<String, dynamic>;
                          return Case(
                            id: doc.id,
                            empresaId: data['empresaId'] ?? '',
                            empresaNombre: data['empresaNombre'] ?? '',
                            nombre: data['nombre'] ?? '',
                            tipoRiesgo: data['tipoRiesgo'] ?? '',
                            descripcionRiesgo: data['descripcionRiesgo'] ?? '',
                            nivelPeligro: _getNivelPeligroActualizado(data),
                            fechaCreacion: (data['fechaCreacion'] as Timestamp?)?.toDate() ?? DateTime.now(),
                            fechaCierre: (data['fechaCierre'] as Timestamp?)?.toDate(),
                            cerrado: data['cerrado'] ?? false,
                          );
                        })
                        .toList();
                    
                    _navegarACasosCerrados(casosCerradosList);
                  },
                );
              },
            ),
          ),
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF6A11CB), Color(0xFF2575FC)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseService.getCasosPorEmpresaStream(_empresaId),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error, size: 64, color: Colors.red),
                    const SizedBox(height: 16),
                    Text('Error: ${snapshot.error}'),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Volver'),
                    ),
                  ],
                ),
              );
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(color: Colors.white),
              );
            }

            if (!snapshot.hasData) {
              return const Center(child: Text('No hay datos', style: TextStyle(color: Colors.white)));
            }

            // Filtrar casos por grupo
            final casosFiltrados = snapshot.data!.docs.where((doc) {
              final data = doc.data() as Map<String, dynamic>;
              return authProvider.puedeAccederRecurso(data['grupoId']);
            }).toList();

            // Separar casos abiertos y cerrados
            final casosAbiertos = <QueryDocumentSnapshot>[];
            final casosCerrados = <Case>[];

            for (var doc in casosFiltrados) {
              final data = doc.data() as Map<String, dynamic>;
              final cerrado = data['cerrado'] ?? false;

              if (!cerrado) {
                casosAbiertos.add(doc);
              } else {
                casosCerrados.add(Case(
                  id: doc.id,
                  empresaId: data['empresaId'] ?? '',
                  empresaNombre: data['empresaNombre'] ?? '',
                  nombre: data['nombre'] ?? '',
                  tipoRiesgo: data['tipoRiesgo'] ?? '',
                  descripcionRiesgo: data['descripcionRiesgo'] ?? '',
                  nivelPeligro: _getNivelPeligroActualizado(data),
                  fechaCreacion: (data['fechaCreacion'] as Timestamp?)?.toDate() ?? DateTime.now(),
                  fechaCierre: (data['fechaCierre'] as Timestamp?)?.toDate(),
                  cerrado: true,
                ));
              }
            }

            if (casosAbiertos.isEmpty) {
              return EmptyCasesState(
                empresaIcon: _empresaIcon ?? Icons.business,
                empresaNombre: _empresa.nombre,
                centroNombre: _centroNombre,
                casosCerradosCount: casosCerrados.length,
                onAddCase: _openAddCaseModal,
                onViewClosedCases: () => _navegarACasosCerrados(casosCerrados),
                puedeAgregar: _puedeCrearCasos(authProvider),
              );
            }

            return Column(
              children: [
                // Header de casos cerrados - configurable
                ConfigurableFeature(
                  feature: 'mostrarCasosCerrados',
                  child: casosCerrados.isNotEmpty
                      ? ClosedCasesHeader(
                          casosCerradosCount: casosCerrados.length,
                          onViewClosedCases: () => _navegarACasosCerrados(casosCerrados),
                        )
                      : const SizedBox.shrink(),
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: casosAbiertos.length,
                    itemBuilder: (context, index) {
                      final doc = casosAbiertos[index];
                      final data = doc.data() as Map<String, dynamic>;
                      final casoId = doc.id;

                      final caso = Case(
                        id: casoId,
                        empresaId: data['empresaId'] ?? '',
                        empresaNombre: data['empresaNombre'] ?? '',
                        nombre: data['nombre'] ?? '',
                        tipoRiesgo: data['tipoRiesgo'] ?? '',
                        descripcionRiesgo: data['descripcionRiesgo'] ?? '',
                        nivelPeligro: _getNivelPeligroActualizado(data),
                        fechaCreacion: (data['fechaCreacion'] as Timestamp?)?.toDate() ?? DateTime.now(),
                        cerrado: false,
                      );

                      return CaseCard(
                        caso: caso,
                        onTap: () => _navegarADetalleCaso(casoId, caso),
                        // Pasar configuración al CaseCard
                        mostrarNivelRiesgo: _debeMostrarNivelRiesgo(caso, configProvider),
                        nivelRiesgoColor: _getNivelRiesgoColor(caso, configProvider),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        ),
      ),
      floatingActionButton: 
          // Mostrar FAB si tiene permisos Y está habilitado en configuración
          _puedeCrearCasos(authProvider) && 
          configProvider.isFeatureEnabled('habilitarCreacionCasos')
            ? FloatingActionButton(
                onPressed: _openAddCaseModal,
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                child: const Icon(FontAwesomeIcons.plus),
              )
            : null,
    );
  }
}